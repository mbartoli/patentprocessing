# XML Handlers

A handler for parsing USPTO XML files must provide the following interface in
order to be immediately compatible with the rest of the toolchain.

DOCUMENTATION COMING

<!--TODO: put this into a class so things can subclass it -->


