# IPython Notebooks

To run a notebook, you need
[iPython](http://ipython.org/ipython-doc/dev/index.html) as well as
[matplotlib](http://matplotlib.org/). Copy the notebook to the directory
containing the sqlite3 files and open using

```
ipython notebook <name-of-file.ipynb>
```

It should open in your browser.
