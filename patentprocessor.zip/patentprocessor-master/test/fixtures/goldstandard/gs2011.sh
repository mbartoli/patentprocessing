#!/bin/sh

echo "Queries the sqlite3 database with 2011 gold standard inventor data"


