bash parse_integration.sh
bash clean_integration.sh
bash consolidate_integration.sh
